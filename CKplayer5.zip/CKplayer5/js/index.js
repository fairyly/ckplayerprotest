$(function(){
    var oli=$("#tabUl li");//�л�
    $("#tabUl li").on("click",function(){
        var that=$(this);
        $("#tabUl li").removeClass("active");
        that.addClass("active");
        $(".contentTab").removeClass("active");
        $(".contentTab").eq(that.index()).addClass("active");
     });
    $(".loadMore").on("click",function(){//加载更多

          $.post("data/data.json",{},function(data){
              for(var data1 in data.photos.items){
                  var fetCurrent=data.photos.items[data1];
                  var domData="<li> <div class='forMargin'> <a> <img src='"+fetCurrent.photo_url+"'> </a> <a class='title'>"+fetCurrent.photo_name+"</a> <div class='com-about'> <span class='comDate'>"+fetCurrent.photo_time+"</span> <p class='readNum'>浏览量：<span>"+fetCurrent.see_mumber+"</span></p><div class='both'></div> </div> </div> </li>";
                  $(".contentTab.active").append(domData);
              }

          },"json")
    });
 })
